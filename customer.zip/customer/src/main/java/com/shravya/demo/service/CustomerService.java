package com.shravya.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.shravya.demo.entity.Customer;
import com.shravya.demo.repository.CustomerRepository;

@Component("cs")
public class CustomerService 
{
	@Autowired
	CustomerRepository customerRepository;
	public Customer create(Customer customer) {
		return customerRepository.save(customer);
	}
	public List<Customer> read() {
		return customerRepository.findAll();
	}
	
	public Customer update(Customer customer) {
		return customerRepository.save(customer);
	}
	public void delete(String customerId) {
		Customer customer = customerRepository.findById(customerId).get();
		customerRepository.delete(customer);
	}

}
